﻿using System;

namespace ToursApp
{
    internal class AddEditPage : Uri
    {
    }
}